EDHM NovaProfile

Created by CMDR Novartis

  Based on CMDR Exigeous' HUD 
  http://arkku.com/elite/hud_editor/#theme_-0.38_0.89_2_-0.15_2_-0.5_1.75_-1_-0.3
  
========================================================  
========================================================

Notes by CMDR GeorjCostanza

Thank you to CMDR Exigeous for allowing us to add his HUD profile to the EDHM Profile Library
You can subscribe to his YouTube channel via this link:
https://www.youtube.com/channel/UC0Rwxz4318EEQGHz_z58nVA


Bloom
-----
There are two versions of NovaProfile, as the original version causes glare / extra bloom on the ship panels
due to the large values used in the colour matrix

If you would like to reduce the glare / bloom, you can
i. Go into the Elite graphics settings and set your bloom quality to High or Medium
   (quality appears to equal strength for this setting)
   
ii. Use the De-bloomed version of this profile


Text Colour
-----------
I recommend using a Custom text colour (setting 4 in Startup-Profile.ini, included with this profile), with the following RGB values:

; Red 
x116 = 1.0

; Green
y116 = 1.0

; Blue
z116 = 0.8

This custom text colour will make the text white on the ship panels
(except for the Ship Name / Clock area .. Elite adds red to these elements)

However, the text on the Station panels and Main Menu will be off-white/cream coloured.
If you don't like that side-effect I recommend experimenting with the text colour options


Good hunting
o7
